import Welcome from './components/Welcome'

const App = () => {
  return <Welcome name="Ram" />
}
export default App
