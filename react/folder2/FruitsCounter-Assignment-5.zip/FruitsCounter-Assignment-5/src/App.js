import FruitsCounter from './components/FruitsCounter'

import './App.css'

const App = () => <FruitsCounter />

export default App
